const images = [
  'images/slide1.jpg',
  'images/slide2.jpg',
  'images/slide3.jpg'
];

let index = 0;
const slideshow = document.getElementById('slideshow');

function showNextImage() {
  index = (index + 1) % images.length;
  slideshow.src = images[index];
}

// Change image every 3 seconds
setInterval(showNextImage, 3000);